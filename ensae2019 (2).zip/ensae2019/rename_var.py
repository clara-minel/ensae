# -*- coding: utf-8 -*-
"""
Created on Tue Nov 19 16:49:54 2019

@author: clara
"""
def piechart_num(var_cat_1,var_cat_2,var_num_1,var_num_2,year_1,year_2,name):
    """La fonction piechart_num permet, Ã  partir de 7 variables, d'afficher deux pie charts.
    L'argument var_cat_1 correspond Ã  une vecteur catÃ©gorielle d'une annÃ©e n d'une base de donnÃ©e
    L'argument var_cat_2 correspond Ã  une vecteur catÃ©gorielle d'une annÃ©e m d'une base de donnÃ©e
    L'argument var_num_1 correspond Ã  une vecteur quantitative de l'annÃ©e n d'une base de donnÃ©e
    L'argument var_num_2 correspond Ã  une vecteur quantitative de l'annÃ©e m d'une base de donnÃ©e
    L'argument year_1 correspond Ã  une annÃ©e donnÃ©e
    L'argument year_2 correspond Ã  une autre annÃ©e donnÃ©e, supposÃ©e supÃ©rieure Ã  n
    L'argument name correspond au nom que l'on veut donner Ã  la reprÃ©sentation"""
    c=var_cat_1.unique()
    d=var_cat_2.unique()
    list1=[]
    for v in c:
        print(v)
        x_v=0
        x_v+=sum(var_num_1[i] for i in range(len(var_num_1)) if var_cat_1[i]==v)
        print(x_v)
        list1.append(x_v)
    print(list1)
    list2=[]
    for v in d:
        print(v)
        x_v=0
        x_v+=sum(var_num_2[i] for i in range(len(var_num_2)) if var_cat_2[i]==v)
        print(x_v)
        list2.append(x_v)
    print(list2)
    fig = make_subplots(rows=1, cols=2, specs=[[{'type':'domain'}, {'type':'domain'}]],
                    subplot_titles=[year_1, year_2])
    fig.add_trace(go.Pie(labels=c,values=list1,scalegroup="one", name=year_1),1,1)
    fig.add_trace(go.Pie(labels=d,values=list2,scalegroup="one", name=year_2),1,2)
    fig.update_layout(title_text=name)
    fig.show()
    
    
def piechart_string(var_cat_1,var_cat_2,var_str_1,var_str_2,year_1,year_2,name):
    """La fonction piechart_string permet, Ã  partir de 7 variables, d'afficher deux pie charts.
    L'argument var_cat_1 correspond Ã  une vecteur catÃ©gorielle d'une annÃ©e n d'une base de donnÃ©e
    L'argument var_cat_2 correspond Ã  une vecteur catÃ©gorielle d'une annÃ©e m d'une base de donnÃ©e
    L'argument var_str_1 correspond Ã  une vecteur de string de l'annÃ©e n d'une base de donnÃ©e
    L'argument var_str_2 correspond Ã  une vecteur de string de l'annÃ©e m d'une base de donnÃ©e
    L'argument year_1 correspond Ã  une annÃ©e donnÃ©e
    L'argument year_2 correspond Ã  une autre annÃ©e donnÃ©e, supposÃ©e supÃ©rieure Ã  n
    L'argument name correspond au nom que l'on veut donner Ã  la reprÃ©sentation"""
    c=var_cat_1.unique()
    d=var_cat_2.unique()
    list1=[]
    for v in c:
        print(v)
        x_v=0
        for i in range(len(var_cat_1)):
            if var_cat_1[i]==v:
                x_v+=1 
        print(x_v)
        list1.append(x_v)
    print(list1)
    list2=[]
    for v in d:
        print(v)
        x_v=0
        for i in range(len(var_cat_2)):
            if var_cat_2[i]==v:
                x_v+=1 
        print(x_v)
        list2.append(x_v)
    print(list2)
    fig = make_subplots(rows=1, cols=2, specs=[[{'type':'domain'}, {'type':'domain'}]],
                    subplot_titles=[n, m])
    fig.add_trace(go.Pie(labels=c,values=list1,scalegroup="one", name=year_1),1,1)
    fig.add_trace(go.Pie(labels=d,values=list2,scalegroup="one", name=year_2),1,2)
    fig.update_layout(title_text=name)
    fig.show()
   
    
  
