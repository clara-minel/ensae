            
"""Défintion des fonctions de notre module"""


    ##Fonction pour faire des pie-charts avec des variables numériques
   ## """importation des packages"

import numpy as np
import pandas
import chardet
import matplotlib.pyplot as plt
from plotly import tools
import chart_studio.plotly as py
import plotly.graph_objs as go
from plotly.subplots import make_subplots
def piechart_num(a,b,z,w,n,m,name):
    """La fonction piechart_num permet, �  partir de 7 variables, d'afficher deux pie charts.
    L'argument a correspond �  une vecteur catégorielle d'une année n d'une base de donnée
    L'argument b correspond �  une vecteur catégorielle d'une année m d'une base de donnée
    L'argument z correspond �  une vecteur quantitative de l'année n d'une base de donnée
    L'argument w correspond �  une vecteur quantitative de l'année m d'une base de donnée
    L'argument n correspond �  une année donnée
    L'argument m correspond �  une autre année donnée, supposée supérieure �  n
    L'argument name correspond au nom que l'on veut donner �  la représentation"""
    c=a.unique()
    d=b.unique()
    list1=[]
    for v in c:
        print(v)
        x_v=0
        x_v+=sum(z[i] for i in range(len(z)) if a[i]==v)
        print(x_v)
        list1.append(x_v)
    print(list1)
    list2=[]
    for v in d:
        print(v)
        x_v=0
        x_v+=sum(w[i] for i in range(len(w)) if b[i]==v)
        print(x_v)
        list2.append(x_v)
    print(list2)
    fig = make_subplots(rows=1, cols=2, specs=[[{'type':'domain'}, {'type':'domain'}]],
                    subplot_titles=[n, m])
    fig.add_trace(go.Pie(labels=c,values=list1,scalegroup="one", name=n),1,1)
    fig.add_trace(go.Pie(labels=d,values=list2,scalegroup="one", name=m),1,2)
    fig.update_layout(title_text=name)
    fig.show()
    

    ##Fonction pour faire des pie-charts avec des variables catégorielles

def piechart_string(a,b,z,w,n,m,name):
    """La fonction piechart_mon_reuf permet, �  partir de 7 variables, d'afficher deux pie charts.
    L'argument a correspond �  une vecteur catégorielle d'une année n d'une base de donnée
    L'argument b correspond �  une vecteur catégorielle d'une année m d'une base de donnée
    L'argument z correspond �  une vecteur de string de l'année n d'une base de donnée
    L'argument w correspond �  une vecteur de string de l'année m d'une base de donnée
    L'argument n correspond �  une année donnée
    L'argument m correspond �  une autre année donnée, supposée supérieure �  n
    L'argument name correspond au nom que l'on veut donner �  la représentation"""
    c=a.unique()
    d=b.unique()
    list1=[]
    for v in c:
        print(v)
        x_v=0
        for i in range(len(a)):
            if a[i]==v:
                x_v+=1 
        print(x_v)
        list1.append(x_v)
    print(list1)
    list2=[]
    for v in d:
        print(v)
        x_v=0
        for i in range(len(b)):
            if b[i]==v:
                x_v+=1 
        print(x_v)
        list2.append(x_v)
    print(list2)
    fig = make_subplots(rows=1, cols=2, specs=[[{'type':'domain'}, {'type':'domain'}]],
                    subplot_titles=[n, m])
    fig.add_trace(go.Pie(labels=c,values=list1,scalegroup="one", name=n),1,1)
    fig.add_trace(go.Pie(labels=d,values=list2,scalegroup="one", name=m),1,2)
    fig.update_layout(title_text=name)
    fig.show()
   
    
    ## Fonction pour les cartes

def plot_geo_time_value(data,variable_of_interest,coordinates,nb_of_periods,title='Titre',plots_per_row=2,plots_per_column=2, scale = 1/40):
    
    """ data, variable_of_interest, coordinates déj�  présentés
    nb_of_periods : le nombre de cartes que l'on veut représenter
    title : le titre que l'on veut donner aux cartes
    plots_per_row : nb de cartes par ligne
    plots_per_columns : nb de cartes par colonne"""
    
    
    fig = plt.figure(figsize=(15,10)) 

    color_ticker = ['green','orange','red','mediumpurple','blue','black','olivedrab','firebrick','aqua','lightcoral','gold','teal','mediumorchid','coral','yellow','lightblue','fuschia']
    

    for i in range(1,nb_of_periods+1):
    
        ax = fig.add_subplot(plots_per_column,plots_per_row,i,projection=ccrs.PlateCarree())
        ax.set_extent(lim_metropole)
        ax.add_feature(cfeature.OCEAN.with_scale('50m'))
        ax.add_feature(cfeature.COASTLINE.with_scale('50m'))
        ax.add_feature(cfeature.RIVERS.with_scale('50m'))
        ax.add_feature(cfeature.BORDERS.with_scale('50m'), linestyle=':')
        ax.scatter(data[i-1][coordinates[i-1][0]], data[i-1][coordinates[i-1][1]],
           s=data[i-1][variable_of_interest[i-1]] ** scale, alpha=0.5, color = color_ticker[i-1])
        ax.set_title(titles[i-1])

    fig.suptitle(title, fontsize=16)
    fig.show()


    ## La fonction barplot permet de réaliser un histogramme avec des variables catégorielles 

""" a = nom de la variable de la colonne provenant du dataframe de la valeur pour l'ann�e t
    b = nom de la variable de la colonne provenant du dataframe de la valeur pour l'ann�e t+1
    h1 = nom de la variable de la colonne provenant du dataframe df19 des cat�gories repr�sent�es en abscisse
    h2 = nom de la variable de la colonne provenant du dataframe df18 des cat�gories repr�sent�es en abscisse  
    absc = titre de l'axe des abcsisses
    ordo = titre de l'axe des ordonn�s
    title = titre du graphique
    z = nombre de cat�gories du barplot
    df19 = nom du dataframe de l'ann�e t+1
    df18 = nom du dataframe de l'ann�e t
    
 """
def barplot_variations(a,b,h1,h2,absc,ordo,z,title,df19,df18):  

    column1= h1
    column4= h2
    column2= a
    column3= b

    
    df19sum = df19.groupby(column1)[column3].sum()

    df18sum = df18.groupby(column4)[column2].sum() 
    
    indexdf19sum = df19sum.index
    indexdf18sum = df18sum.index

         
    df18sum=pandas.DataFrame(df18sum)
    df19sum=pandas.DataFrame(df19sum)
    df18sum.rename(columns={a: 'V1'}, inplace=True)
    df19sum.rename(columns={b: 'V2'}, inplace=True)
    df2=pandas.merge(df18sum,df19sum, on=h1 )
    df2['Variation']=(df2['V2']-df2['V1'])*100/df2['V1']
    df2['Sous-domaine'] =  df2.index


    plt.bar(x=np.arange(1,z),height=df2['Variation'])
    plt.title(title)
    plt.xlabel(absc)
    plt.ylabel(ordo)
    plt.xticks(np.arange(1,z), df2['Sous-domaine'], rotation=90)

    plt.show()
